// 메루카리 상품 페이지에서 실행되는 content script
// 현재는 popup에서 직접 분석하므로 특별한 기능 없음
// 추후 페이지 내 플로팅 버튼 등을 추가할 때 사용

console.log('[Buylink] 메루카리 상품 페이지 감지됨');
