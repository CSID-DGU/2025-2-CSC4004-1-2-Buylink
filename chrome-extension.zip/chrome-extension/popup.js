// API 서버 주소
const API_BASE_URL = 'http://211.188.56.255:17788';

// 상태 관리
let currentUrl = null;

// DOM 요소
const states = {
  notMercari: document.getElementById('not-mercari'),
  ready: document.getElementById('ready'),
  loading: document.getElementById('loading'),
  result: document.getElementById('result'),
  error: document.getElementById('error')
};

// 상태 전환
function showState(stateName) {
  Object.values(states).forEach(el => el.classList.add('hidden'));
  states[stateName].classList.remove('hidden');
}

// 숫자 포맷팅
function formatNumber(num) {
  return new Intl.NumberFormat('ko-KR').format(num);
}

// 무게 표시 (g 또는 kg)
function formatWeight(kg) {
  if (kg < 1) {
    return `${Math.round(kg * 1000)}g`;
  }
  return `${kg.toFixed(2)}kg`;
}

// 부피 표시 (cm³)
function formatVolume(m3) {
  const cm3 = m3 * 1000000; // m³ → cm³
  return `${formatNumber(Math.round(cm3))}cm³`;
}

// 로딩 텍스트 업데이트
function setLoadingText(text) {
  document.getElementById('loading-text').textContent = text;
}

// EMS 배송비 계산 (1구역 - 한국)
function calculateEmsYen(weightKg) {
  const rates = [
    { maxKg: 0.5, yen: 1450 },
    { maxKg: 1.0, yen: 2200 },
    { maxKg: 1.5, yen: 2800 },
    { maxKg: 2.0, yen: 3400 },
    { maxKg: 2.5, yen: 4000 },
    { maxKg: 3.0, yen: 4550 },
    { maxKg: 3.5, yen: 5100 },
    { maxKg: 4.0, yen: 5650 },
    { maxKg: 4.5, yen: 6200 },
    { maxKg: 5.0, yen: 6750 },
    { maxKg: 5.5, yen: 7300 },
    { maxKg: 6.0, yen: 7850 },
    { maxKg: 7.0, yen: 8700 },
    { maxKg: 8.0, yen: 9550 },
    { maxKg: 9.0, yen: 10400 },
    { maxKg: 10.0, yen: 11250 }
  ];

  for (const rate of rates) {
    if (weightKg <= rate.maxKg) {
      return rate.yen;
    }
  }

  // 10kg 초과: 기본 요금 + 추가 kg당 800엔
  const extraKg = Math.ceil(weightKg - 10);
  return 11250 + (extraKg * 800);
}

// 10원 단위 올림
function roundUp10(value) {
  return Math.ceil(value / 10) * 10;
}

// 견적 계산
function calculateEstimate(priceKRW, weightKg, volumeM3) {
  // 1. 상품 금액
  const productTotal = priceKRW;

  // 2. 대행 수수료 (5%)
  const serviceFee = roundUp10(productTotal * 0.05);

  // 3. 부피 무게 계산 (cm³ * 0.2밀도계수 / 1000)
  const volumeCm3 = volumeM3 * 1000000;
  const volumetricWeightKg = (volumeCm3 * 0.2) / 1000;

  // 4. 적용 무게 (실무게 vs 부피무게 중 큰 값)
  const chargeableWeightKg = Math.max(weightKg, volumetricWeightKg);

  // 5. EMS 국제 배송비
  const emsYen = calculateEmsYen(chargeableWeightKg);
  const internationalShipping = roundUp10(emsYen * 10); // 1엔 = 10원

  // 6. 국내 배송비
  const domesticShipping = 3000;

  // 7. 총 배송비
  const totalShipping = internationalShipping + domesticShipping;

  // 8. 결제 수수료 (3.4%)
  const paymentFee = roundUp10((productTotal + serviceFee + totalShipping) * 0.034);

  // 9. 총 금액
  const grandTotal = productTotal + serviceFee + totalShipping + paymentFee;

  return {
    productTotal,
    serviceFee,
    internationalShipping,
    domesticShipping,
    paymentFee,
    grandTotal,
    chargeableWeightKg
  };
}

// 결과 표시
function displayResult(productInfo, prediction) {
  // 상품 정보
  document.getElementById('product-image').src = productInfo.imageUrls?.[0] || '';
  document.getElementById('product-name').textContent = productInfo.productName;
  document.getElementById('product-price').textContent = `¥${formatNumber(productInfo.priceKRW)}`;

  // AI 예측 정보
  document.getElementById('weight').textContent = formatWeight(prediction.weight);
  document.getElementById('volume').textContent = formatVolume(prediction.volume);

  // 견적 계산
  const estimate = calculateEstimate(productInfo.priceKRW, prediction.weight, prediction.volume);

  // 견적 내역
  document.getElementById('product-total').textContent = `${formatNumber(estimate.productTotal)}원`;
  document.getElementById('service-fee').textContent = `${formatNumber(estimate.serviceFee)}원`;
  document.getElementById('international-shipping').textContent = `${formatNumber(estimate.internationalShipping)}원`;
  document.getElementById('domestic-shipping').textContent = `${formatNumber(estimate.domesticShipping)}원`;
  document.getElementById('payment-fee').textContent = `${formatNumber(estimate.paymentFee)}원`;
  document.getElementById('grand-total').textContent = `${formatNumber(estimate.grandTotal)}원`;

  showState('result');
}

// 에러 표시
function showError(message) {
  document.getElementById('error-message').textContent = message;
  showState('error');
}

// API 호출: 상품 정보 크롤링
async function fetchProductInfo(url) {
  const response = await fetch(`${API_BASE_URL}/api/products/fetch`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ url })
  });

  if (!response.ok) {
    throw new Error('상품 정보를 가져올 수 없습니다');
  }

  const data = await response.json();
  if (!data.success) {
    throw new Error(data.error || '상품 정보를 가져올 수 없습니다');
  }

  return data.data;
}

// API 호출: AI 예측
async function predictWeightVolume(productInfo) {
  const response = await fetch(`${API_BASE_URL}/api/products/predict`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      success: true,
      data: productInfo,
      error: null
    })
  });

  if (!response.ok) {
    throw new Error('무게/부피 예측에 실패했습니다');
  }

  const data = await response.json();
  if (!data.success) {
    throw new Error(data.error || '무게/부피 예측에 실패했습니다');
  }

  return data.data;
}

// 분석 실행
async function analyze() {
  if (!currentUrl) return;

  showState('loading');

  try {
    // 1단계: 상품 정보 크롤링
    setLoadingText('상품 정보를 가져오는 중...');
    const productInfo = await fetchProductInfo(currentUrl);

    // 2단계: AI 예측
    setLoadingText('무게와 부피를 예측하는 중...');
    const prediction = await predictWeightVolume(productInfo);

    // 3단계: 결과 표시
    displayResult(productInfo, prediction);

  } catch (error) {
    console.error('분석 오류:', error);
    showError(error.message || '분석 중 오류가 발생했습니다');
  }
}

// 현재 탭 URL 확인
async function checkCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab?.url && tab.url.includes('jp.mercari.com/item/')) {
      currentUrl = tab.url;
      showState('ready');
    } else {
      showState('notMercari');
    }
  } catch (error) {
    console.error('탭 확인 오류:', error);
    showState('notMercari');
  }
}

// 이벤트 리스너
document.getElementById('analyze-btn').addEventListener('click', analyze);
document.getElementById('retry-btn').addEventListener('click', analyze);
document.getElementById('error-retry-btn').addEventListener('click', analyze);

// 초기화
document.addEventListener('DOMContentLoaded', checkCurrentTab);
